%keluarga berjenis kelamin laki-laki
laki(harusu).
laki(muis).
laki(mulyadi).
laki(edi).
laki(adi).
laki(agung).
laki(ugar).

%keluarga berjenis kelamin perempuan
perempuan(musuri).
perempuan(nurmin).
perempuan(nurhani).
perempuan(fiani).
perempuan(firah).
perempuan(lili).
perempuan(firda).
perempuan(nisa).
perempuan(aura).

%Orangtua dari masing-masing anak
orangtua(harusu, nurmin).
orangtua(musuri, nurmin).
orangtua(harusu, nurhani).
orangtua(musuri, nurhani).
orangtua(harusu, mulyadi).
orangtua(musuri, mulyadi).
orangtua(harusu, edi).
orangtua(musuri, edi).
orangtua(harusu, fiani).
orangtua(musuri, fiani).
orangtua(harusu, firah).
orangtua(musuri, firah).
orangtua(harusu, adi).
orangtua(musuri, adi).
orangtua(harusu, lili).
orangtua(musuri, lili).

orangtua(muis, agung).
orangtua(nurhani, agung).
orangtua(muis, ugar).
orangtua(nurhani, ugar).
orangtua(muis, nisa).
orangtua(nurhani, nisa).

orangtua(ugar, aura).
orangtua(firda, aura).

%Query mencari orangtua dalam silsilah
ibu(X, Y):-orangtua(X, Y),perempuan(X).
ayah(X, Y):-orangtua(X,Y),laki(X).

anak(X, Y):-orangtua(Y, X).
anak_lakilaki(X, Y):-orangtua(Y, X), laki(X).
anak_perempuan(X, Y):-orangtua(Y, X), perempuan(Y).

menikah(X,Y) :- anak(P, X), anak(P,Y).
istri(Y,X) :- anak(P,X), anak(P,Y), perempuan(Y).
suami(Y,X) :- anak(P,X), anak(P,Y), laki(Y).

menantu(X,Z):- menikah(X,Y), orangtua(Z,Y).
mertua(X,Z):- orangtua(X,Y), menikah(Y,Z).

kakek(X,Z) :- orangtua(X,Y), orangtua(Y,Z), laki(X).
nenek(X,Z) :- ibu(X,Y), orangtua(Y, Z), perempuan(X).

saudara(Y,Z) :- anak(Y,X), anak(Z,X).
saudara_lakilaki(Y,Z) :- anak(Y,X), anak(Z,X), laki(Y).
saudara_perempuan(Y,Z) :- anak(Y,X), anak(Z,X), perempuan(Y).

bibi(X,Y) :- saudara(X,Z), orangtua(Z, Y), perempuan(X), not(ibu(X,Y)).
paman(X,Y) :- saudara(X,Z), orangtua(Z,Y), laki(X), not(ayah(X,Y)).

keponakan(X,Y) :- anak(X,Z), saudara(Z,Y).
keponakan_laki(X,Y) :- anak(X,Z), saudara(Z,Y), laki(X).
keponakan_perempuan(X,Y):- anak(X,Z), saudara(Z,Y), perempuan(X).


cucu(X, Z):- anak(X,Y), orangtua(Z,Y).
cucu_laki(X,Z) :- anak(X,Y), orangtua(Z,Y), laki(X).
cucu_perempuan(X,Z) :- anak(X,Y), orangtua(Z,Y), perempuan(X).

cicit(X,Z):- anak(X, Y), cucu(Y,Z).
buyut(X,Z):- cucu(Y,X), anak(Z,Y).

ipar(X, Z):- (saudara(X, Y), menikah(Y, Z));(menikah(X, Y), saudara(Y,Z)).









