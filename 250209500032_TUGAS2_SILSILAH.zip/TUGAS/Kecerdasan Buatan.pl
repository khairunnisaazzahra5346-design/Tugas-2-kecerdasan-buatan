it_is(summer).
it_is(winter).
it_is(sunny).
it_is(snowing).


it_is(hot):- it_is(summer), it_is(sunny).
it_is(cold):- it_is(winter); it_is(snowing).
